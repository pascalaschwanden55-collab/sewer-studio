using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class BuilderPage : UserControl
{
    public BuilderPage()
    {
        InitializeComponent();
    }
}
