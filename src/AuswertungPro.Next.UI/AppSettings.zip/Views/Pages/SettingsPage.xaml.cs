using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class SettingsPage : System.Windows.Controls.UserControl
{
    public SettingsPage()
    {
        InitializeComponent();
    }
}
