using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class DiagnosticsPage : System.Windows.Controls.UserControl
{
    public DiagnosticsPage()
    {
        InitializeComponent();
    }
}
