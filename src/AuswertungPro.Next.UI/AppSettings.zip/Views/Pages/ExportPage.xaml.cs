using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class ExportPage : System.Windows.Controls.UserControl
{
    public ExportPage()
    {
        InitializeComponent();
    }
}
