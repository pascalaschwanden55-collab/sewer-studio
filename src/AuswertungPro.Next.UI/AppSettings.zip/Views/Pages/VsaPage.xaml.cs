using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class VsaPage : System.Windows.Controls.UserControl
{
    public VsaPage()
    {
        InitializeComponent();
    }
}
