using System.Windows.Controls;

namespace AuswertungPro.Next.UI.Views.Pages;

public partial class ImportPage : System.Windows.Controls.UserControl
{
    public ImportPage()
    {
        InitializeComponent();
    }
}
