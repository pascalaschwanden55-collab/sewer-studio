using System.Windows;

namespace AuswertungPro.Next.UI.Views.Windows;

public partial class CombinedOfferWindow : Window
{
    public CombinedOfferWindow()
    {
        InitializeComponent();
    }
}
