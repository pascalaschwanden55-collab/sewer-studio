using System.Windows;

namespace AuswertungPro.Next.UI.Views.Windows;

public partial class CodeCatalogEditorWindow : Window
{
    public CodeCatalogEditorWindow()
    {
        InitializeComponent();
    }
}
