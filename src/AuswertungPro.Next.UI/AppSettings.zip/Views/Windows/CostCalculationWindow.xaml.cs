using System.Windows;

namespace AuswertungPro.Next.UI.Views.Windows;

public partial class CostCalculationWindow : Window
{
    public CostCalculationWindow()
    {
        InitializeComponent();
    }
}
