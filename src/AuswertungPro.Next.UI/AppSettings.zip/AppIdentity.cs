namespace AuswertungPro.Next.UI;

public static class AppIdentity
{
    public const string ProductName = "SewerStudio";

    // Legacy folder names used by earlier versions.
    public const string LegacyLocalDataFolder = "AuswertungPro.Next";
    public const string LegacyRoamingDataFolder = "AuswertungPro";
}
